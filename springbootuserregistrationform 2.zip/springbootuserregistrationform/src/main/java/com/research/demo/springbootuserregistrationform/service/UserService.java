package com.research.demo.springbootuserregistrationform.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.research.demo.springbootuserregistrationform.model.User;
import com.research.demo.springbootuserregistrationform.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService {

    User findByEmail(String email);

    User save(UserRegistrationDto registration);
}