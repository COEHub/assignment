package springboot.springbootassignment.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import springboot.springbootassignment.model.User;

public class UserStub {
	private static Map<Long, User> user = new HashMap<Long, User>();
	private static Long idIndex = 3L;

	static {
		User a = new User(1L, "A123", "serenejames@gmail.com");
		user.put(1L, a);
		User b = new User(2L, "B456", "anishkora@yahoo.com");
		user.put(2L, b);
		User c = new User(3L, "C789", "zubinantony@hotmail.com");
		user.put(3L, c);
	}

	public static List<User> list() {
		return new ArrayList<User>(user.values());
	}

	public static User create(User wreck) {
		idIndex += idIndex;
		wreck.setId(idIndex);
		user.put(idIndex, wreck);
		return wreck;
	}

	public static User get(Long id) {
		return user.get(id);
	}

	public static User update(Long id, User wreck) {
		user.put(id, wreck);
		return wreck;
	}

	public static User delete(Long id) {
		return user.remove(id);
	}
}
