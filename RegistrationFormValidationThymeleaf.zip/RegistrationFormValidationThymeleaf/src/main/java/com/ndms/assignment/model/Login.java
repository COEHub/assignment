package com.ndms.assignment.model;

public class Login {

	private String userName;
	
	public Login(String userName, String encrytedPassword) {
		super();
		this.userName = userName;
		this.encrytedPassword = encrytedPassword;
	}
	public Login() {
		super();
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEncrytedPassword() {
		return encrytedPassword;
	}
	public void setEncrytedPassword(String encrytedPassword) {
		this.encrytedPassword = encrytedPassword;
	}
	private String encrytedPassword;

}
