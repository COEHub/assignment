package com.ndms.assignment.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import com.ndms.assignment.formbean.LoginForm;
import com.ndms.assignment.model.Login;
import com.ndms.assignment.model.AppUser;

@Repository
public class LoginDAO {

	// Config in WebSecurityConfig
	@Autowired
	private PasswordEncoder passwordEncoder;

	private static final Map<Long, AppUser> USERS_MAP = new HashMap<>();

	public AppUser findLoginByUserName(String userName) {
		Collection<AppUser> login = USERS_MAP.values();
		for (AppUser u : login) {
			if (u.getUserName().equals(userName)) {
				return u;
			}
		}
		return null;
	}

}
