package com.ndms.assignment.validator;

import com.ndms.assignment.dao.LoginDAO;
import com.ndms.assignment.model.AppUser;
import com.ndms.assignment.formbean.LoginForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class LoginValidator implements Validator {

	@Autowired
	private LoginDAO loginDAO;

	// The classes are supported by this validator.
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz == LoginForm.class;
	}

	@Override
	public void validate(Object target, Errors errors) {
		LoginForm loginForm = (LoginForm) target;

		// Check the fields of AppUserForm.
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "NotEmpty.appUserForm.userName");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.appUserForm.password");

		if (!errors.hasFieldErrors("userName")) {
			AppUser dbUser = loginDAO.findLoginByUserName(loginForm.getUserName());
			if (dbUser != null) {
				// Username is not available.
				errors.rejectValue("userName", "Duplicate.LoginForm.userName");
			}
		}

	}
}
